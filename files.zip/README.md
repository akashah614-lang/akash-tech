# akash.tech

Personal portfolio and project showcase.

---

## File structure

```
akash-tech/
├── index.html                          # Homepage
├── style.css                           # Shared styles (all pages)
├── README.md                           # This file
└── projects/
    └── agent-kit-generator.html        # Project page template
```

---

## How to add a new project

### 1. Add a card to the homepage (`index.html`)

Inside the `<div class="project-grid">`, copy and paste this block, then fill in the details:

```html
<a href="projects/YOUR-SLUG.html" class="project-card">
  <div class="card-meta">
    <span class="card-num">05</span>       <!-- increment the number -->
    <span class="tag">Category</span>      <!-- e.g. AI Tooling, Fintech, Design -->
  </div>
  <div class="card-body">
    <h2 class="card-title">Project Name</h2>
    <p class="card-desc">One sentence that describes what this does.</p>
  </div>
  <div class="card-footer">
    <span class="card-link-label">View project</span>
    <span class="card-arrow">↗</span>
  </div>
</a>
```

If the project page isn't ready yet, set `href="#"` and change the footer label to "Coming soon" and the arrow to `→`.

---

### 2. Create the project page

Duplicate `projects/agent-kit-generator.html` and rename it `projects/YOUR-SLUG.html`.

Fill in the following:

| Field | Where to find it |
|---|---|
| `<title>` | In the `<head>` tag — `Project Name — Akash` |
| `<meta name="description">` | One-line summary for SEO |
| Category tag | The `<span class="tag">` near the top of `.project-hero` |
| Project title | The `<h1 class="project-title">` — use `<em>` for the italic word |
| Tagline | The `<p class="project-tagline">` |
| Why I built this | The three `<p>` tags inside `.prose` |
| Feature tiles | The four `.feature-tile` blocks inside `.feature-grid` |
| Stack pills | The `.pill` spans inside `.stack-pills` |
| CTA link | The `href="#"` on `.btn-primary` |

---

### 3. Design rules to keep in mind

- **No drop shadows.** Cards use borders only.
- **Serif accent sparingly.** Use `<em>` inside headings to trigger the _Instrument Serif_ italic. One use per heading, max.
- **Tags are all-caps.** Handled by CSS — just type normal case in HTML.
- **Section labels** use the `section-label` class — all-caps, tracked out, muted gray.
- **Muted body copy** on project pages uses `color: var(--text-muted)` and `font-weight: 300` — this is already set in `.prose p`.

---

### 4. Fonts

The site loads from Google Fonts:
- **DM Sans** — body text, UI, labels
- **Instrument Serif Italic** — display accent (triggered via `<em>` inside headings)

Both load via `@import` in `style.css`. No install needed.

---

### 5. Deploying to GitHub Pages

```bash
# From your repo root
git add .
git commit -m "Add [project name] project page"
git push origin main
```

If you're on GitHub Pages, make sure the repo is set to serve from `main` / root in Settings → Pages.

---

### Color tokens (for reference)

```css
--bg:        #f9f9f7   /* page background */
--surface:   #ffffff   /* cards, tiles */
--text:      #1a1a1a   /* primary text */
--text-muted:#6b6b65   /* secondary text, body copy */
--border:    #e8e8e4   /* light borders */
--border-mid:#d4d4ce   /* slightly stronger borders */
--tag-bg:    #f0f0ec   /* tag pill background */
```

---

Built by Akash. Last updated 2025.
